To Compile: 
	$make

